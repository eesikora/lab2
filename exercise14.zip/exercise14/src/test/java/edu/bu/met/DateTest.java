package edu.bu.met;

import static org.junit.Assert.*;

import org.junit.Test;

import exercise14.Date;

public class DateTest {

	@Test
	public void test() {
		Date myTestDate = new Date(1,1,1);
		String expectedOutput = myTestDate.displayDate();
		
		if (!expectedOutput.equals("1/1/1") ) {
			fail("Output is incorrect");
		}
	
	}

	@Test
	public void blowMyNose() {
		Date d1 = new Date();
		String s = d1.displayDate();
		
		if (!s.equals("0/0/0")) {
			fail("This should pass, but it didn't");
		}
	}
	
	@Test
	public void negativeTestCase() {
		Date d1 = null;
		String s = d1.displayDate();
	}
}
